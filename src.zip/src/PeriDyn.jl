module PeriDyn

greet() = print("Hello World!")

end # module
